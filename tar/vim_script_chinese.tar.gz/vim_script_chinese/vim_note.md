echo
echom

`nnoremap`命令中的`<buffer>`告诉Vim这个映射只在定义它的那个缓冲区中有效：

autocmd BufNewFile 
