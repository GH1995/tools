﻿《算法竞赛入门经典》第二版 范例代码

刘汝佳

第八章

例题代码

8-1 UVa120 Stacks of Flapjacks

8-2 UVa1605 Building for UN

8-3 UVa1152 4 Values Whose Sum is Zero

8-4 UVa11134 Fabled Rooks

8-5 UVa11054 Wine trading in Gergovia

8-6 UVa1606 Amphiphilic Carbon Molecules

8-7 UVa11572 Unique snowflakes

8-8 UVa1471 Defense Lines

8-9 UVa1451 Average

8-10 UVa714 Copying Books

8-11 UVa10954 Add All

8-12 UVa12627 Erratic Expansion

8-13 UVa11093 Just Finish it up

8-14 UVa1607 Gates

8-15 UVa12174 Shuffle

8-16 UVa1608 Non-boring sequences

8-17 UVa1609 Foul Play

8-18 UVa1442 Cave

8-19 UVa12265 Selling Land
