﻿《算法竞赛入门经典》第二版 范例代码

刘汝佳

第十二章

例题代码

提交：http://uva.onlinejudge.org/index.php?option=com_onlinejudge&Itemid=8&category=856

12-1 UVa1671 History of Languages

12-2 UVa1672 Disjoint Regular Expressions

12-3 UVa1673 str2int

[暂缺]12-4 UVa12161 Ironman Race in Treeland

[暂缺]12-5 UVa11994 Happy Painting

[暂缺]12-6 UVa1674 Lightning Energy Report

12-7 UVa12538 Version Controlled IDE

[暂缺]12-8 UVa805 Polygon Intersections

[暂缺]12-9 UVa1675 Kingdom Reunion

[暂缺]12-10 UVa12314 The Cleaning Robot

[暂缺]12-11 UVa1520 Flights

[暂缺]12-12 UVa1676 GRE Words Revenge

[暂缺]12-13 UVa11998 Rujia Liu Loves Wario Land!

[暂缺]12-14 UVa1104 Chips Challenge

[暂缺]12-15 UVa12567 Never7, Ever17 and Wa[t]er

[暂缺]12-16 UVa12110 Gargoyle

[暂缺]12-17 UVa12253 Simple Encryption

[暂缺]12-18 UVa12164 The Great Game

[暂缺]12-19 UVa1677 Cycling

[暂缺]12-20 UVa1678 Huzita Axiom 6

[暂缺]12-21 UVa1679 Easy Geometry

[暂缺]12-22 UVa12162 Shooting the Monster

[暂缺]12-23 UVa1017 Merrily, We Roll Along!

[暂缺]12-24 UVa1286 Room Services

[暂缺]12-25 UVa1288 Shortest Flight Path

[暂缺]12-26 UVa12565 Lovely M[a]gical Curves

[暂缺]12-27 UVa11188 A Strange Opera House

[暂缺]12-28 UVa12308 Smallest Enclosing Box

[暂缺]12-29 UVa1680 Journey

[暂缺]12-30 UVa1097 Rain

[暂缺]12-31 UVa1681 Dictionary

[暂缺]12-32 UVa11199 Equations in Disguise

[暂缺]12-33 UVa1682 Exclusive Access

[暂缺]12-34 UVa11521 Compressor

[暂缺]12-35 UVa12417 Formula Editor

[暂缺]12-36 UVa12666 Killer Puzzle

[暂缺]12-37 UVa12731 Mysterious Space Station
