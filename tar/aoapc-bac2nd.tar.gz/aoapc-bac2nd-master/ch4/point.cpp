struct Point { double x, y; /\r/\r/g;

double dist(Point a, Point b)
{
  return 0;
}

int main() {
  return 0;
}
