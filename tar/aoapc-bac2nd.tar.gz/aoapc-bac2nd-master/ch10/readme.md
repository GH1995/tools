﻿《算法竞赛入门经典》第二版 范例代码

刘汝佳

第十章

例题代码

10-1 UVa11582 Colossal Fibonacci Numbers!

10-2 UVa12169 Disgruntled Judge

10-3 UVa10375 Choose and Divide

10-4 UVa10791 Minimum Sum LCM

10-5 UVa12716 GCD XOR

10-6 UVa1635 Irrelevant Elements

10-7 UVa10820 Send a Table

10-8 UVa1262 Password

10-9 UV1636 Headshot

10-10 UVa10491 Cows and Cars

10-11 UVa11181 Probability|Given

10-12 UVa1637 Double Patience

10-13 UVa580 Critical Mass

10-14 UVa12034 Race

10-15 UVa1638 Pole Arrangement

10-16 UVa12230 Crossing Rivers

10-17 UVa1639 Candy

10-18 UVa10288 Coupons （附数据）

10-19 UVa11346 Probability

10-20 UVa10900 So you want to be a 2n-aire?

10-21 UVa11971 Polygon

10-22 UVa1640 The Counting Problem

10-23 UVa10213 How Many Pieces of Land?

10-24 UVa1641 ASCII Area

10-25 UVa1363 Joseph's Problem

10-26 UVa11440 Help Mr. Tomisu （附数据）

10-27 UVa10214 Trees in a Wood

10-28 UVa1393 Highway

10-29 UVa1642 Magical GCD
