#!/bin/bash 

echo "The original parameters: $*"
shift 2
echo "Here's the new parameter: $1"
