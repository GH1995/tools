#!/bin/bash

list="a b c d r f"

for s in $list 
do
    echo "Have you : $s"
done
