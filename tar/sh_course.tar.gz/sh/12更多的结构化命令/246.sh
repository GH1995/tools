#!/bin/bash 
# basic for command 

for test in a b c d 
do 
    echo "the next s is $test."
done
