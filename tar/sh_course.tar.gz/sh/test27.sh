#!/bin/bash 

read -s -p "Enter your password: " pass
echo
echo  "Is your password really $pass?"
