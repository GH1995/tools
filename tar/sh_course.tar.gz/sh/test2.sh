#!/bin/bash
# testing variables
days=10
guest="Kate"
echo "$guest checked in $days ago"
days=5
guest="J"
echo "$guest checked in $days ago"
