#!/bin/bash
#display  user information from the system
echo "User info for userid: $USER"
echo  HOME:$HOME
