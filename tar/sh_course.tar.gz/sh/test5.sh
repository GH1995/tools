#!/bin/bash 
name=`basename $0`
echo The command entered is: $name
