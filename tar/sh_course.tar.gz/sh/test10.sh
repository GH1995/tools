#!/bin/bash 
params=$#
echo "The last parameter is $params"
echo "The last parameter is ${!#}"
