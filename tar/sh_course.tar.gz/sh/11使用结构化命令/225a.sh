# 嵌套if
#
if command
then
    command  
elif  command  
then  
    command 
if
