#!/bin/bash 
#testing string equality

testuser=hxs

if [ $USER = $testuser ]
then 
    echo "welcome $testuser"
fi

