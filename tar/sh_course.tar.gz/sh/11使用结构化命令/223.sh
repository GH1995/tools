#!/bin/bash
# test the if statement
if date 
then
    echo "it worked"
fi
