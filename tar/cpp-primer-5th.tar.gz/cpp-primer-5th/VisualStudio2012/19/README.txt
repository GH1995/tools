
None of the programs in this chapter read input.

