Some programs read cin for their input.
Sample data files are in the data directory:

     File           Programs that use that input file
     ----           --------
   erase            erase

Programs not listed above print output and do
not read any input

