Some programs read cin for their input.
Sample data files are in the data directory:

     File           Programs that use that input file
     ----           --------
   vecSubs          cond

Programs not listed above print output and do
not read any input

