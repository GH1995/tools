No programs in this chapter read input.
Sample data files are in the data directory:

     File           Programs that use that input file
     ----           --------

Programs not listed above print output and do
not read any input

