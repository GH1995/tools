#my_max1.py
def my_max1(a, b):
    if a > b: print(a, '>', b)
    elif a == b: print(a, '=', b)
    else: print(a, '<', b)
my_max1(1, 2)
x = 11; y = 8
my_max1(x, y)
my_max1(1)
