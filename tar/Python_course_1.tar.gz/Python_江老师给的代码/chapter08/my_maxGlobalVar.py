#my_maxGlobalVar.py
def my_max(a, b):
    if a > b: print(a, '>', b)
    elif a == b: print(a, '=', b)
    else: print(a, '<', b)
my_max(1, 2)
x = 11; y = 8
my_max(x, y)
my_max(1)
