#my_add.py
def my_add(a, b): #声明函数，返回值
    return(a+b)
def my_print(msg): #声明函数，无返回值
    print(msg)
c = my_add(11, 22) #调用函数
my_print(c)        #调用函数
