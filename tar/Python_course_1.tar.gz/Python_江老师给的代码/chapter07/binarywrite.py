#binarywrite.py
with open(r'c:\python\data1.dat', 'wb') as f:
    f.write(b'123') #写入字节数据
    f.write(b'abc') #写入字节数据
