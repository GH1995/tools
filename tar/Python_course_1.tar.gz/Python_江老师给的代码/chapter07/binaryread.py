#binaryread.py
with open(r'c:\python\data1.dat', 'rb') as f:
    b = f.read()
    print(b)
