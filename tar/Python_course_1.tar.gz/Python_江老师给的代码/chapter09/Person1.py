#Person1.py
class Person1:  #定义类Person1
    pass      #类体为空语句
p1 = Person1()  #创建和使用对象
print(p1)
