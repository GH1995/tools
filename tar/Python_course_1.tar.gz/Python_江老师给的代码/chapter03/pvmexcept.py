i1 = 1
i2 = 0
print(i1/i2)
