#chapter02\Person.py
class Person:           #定义类Person
    def sayHello(self):  #定义类Person的函数sayHi
        print('Hello, how are you?')
p = Person()           #创建对象
p.sayHello()           #调用对象的方法
