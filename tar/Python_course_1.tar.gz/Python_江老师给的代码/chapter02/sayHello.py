#chapter02\sayHello.py
def sayHello():             #定义函数sayHello
    print('Hello World!')     #函数体
    print('To be or not to be, this is a question!') #函数体
sayHello()                #调用函数sayHello
