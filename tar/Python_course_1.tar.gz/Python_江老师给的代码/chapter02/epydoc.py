#chapter02\epydoc.py
'''
@version: $Id$
@author: U{username<mailto: email_address>}
@see: 资料
'''
import sys, os, other
class Templates(object):
    '''
    类说明
    '''
    def __init__(self, param1):
        '''
        @param param1: 注释内容。
         @type param1: 介绍。
         @return: 返回简介。
         @rtype v： 返回类型简介。
         '''
        self.param1 = param1
