#chapter02\doc.py
"""doc模块说明文档""" #模块注释
def d2b(i):
    """函数d2b的说明文档""" #模块注释
    print(bin(i))
class Doc:  #定义类Person
    """类Doc的说明文档"""
    def sayHello(self): #定义类Person的函数sayHi
        """方法sayHello的说明文档"""
        print('hi')
