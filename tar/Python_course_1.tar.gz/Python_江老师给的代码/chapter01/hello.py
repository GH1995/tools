﻿#chapter01\hello.py A "hello world!" program
import random # 导入库模块
print('Good Luck!') # 输出：Good Luck!
print('你今天的幸运随机数是：',random.choice(range(10))) # 输出从0到9之间随机选择的数
input() # 等待用户输入
