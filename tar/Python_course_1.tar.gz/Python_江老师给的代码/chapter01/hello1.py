#chapter01\hello1.py A "hello world" program
import math
print('hello world') #输出：hello world
print('2的128次方：', math.pow(2,128)) #输出2的128次方

