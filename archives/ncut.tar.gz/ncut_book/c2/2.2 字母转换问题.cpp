/*

*/\r/\r/g
while (1)		// 重复读入所有的测试数据
{
	gets(strb);	// 读入数据的第一行
	if (strcmp(strb, "ENDOFINPUT") == 0)
		break;	// 读入结束串，结束程序
	gets(str);	// 读入数据字符串
				
				// 处理读入的串
	/*
	*/

	gets(strb);	// 读入"END"串
}
